var AWS = require("aws-sdk");

console.log("Region: ", AWS.config.region);
